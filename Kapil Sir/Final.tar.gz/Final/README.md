# Download Anaconda(Python 2.7 version) from below link:
https://www.anaconda.com/download/

# installation guide
https://docs.continuum.io/anaconda/install/

# in Ubuntu
# Open CMD & type following command
$ go/to/project/folder
$ jupyter notebook CSC8001-A2_Copy_1.ipynb



NOTES:
1) For Window PATH should be different, so Set Path accordingly
2) Extract data.rar 
